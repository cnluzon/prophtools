================================================================
ProphTools v1.0. Tools for Heterogeneous Network prioritization
================================================================

Authors: Carmen Navarro Luzón, Víctor Martínez Gómez

Prioritization
==============

Subsubsection title..
^^^^^^^^^^^^^^^^^^^^^


ProphTools includes a set of tools for network prioritization based on
the methodology used to create ProphNet, a web based prioritization tool
that performs queries on a gene-domain-disease network.

The methodology has been generalized to be able to handle any type of network
configuration, so as a user you can now download ProphTools package, set up
your data as a network configuration and run queries and performance tests on
it. 

License
=======
Source code is in python and provided under the GPLv3.0 license. 

Prophnet allows to perform prioritization on a set of interconnected
network, prioritizing from a query network to the target network by means
of a hybrid approach including a Random Walk with Restarts within network
approach and propagation across different networks based on these results. 
In the end, the scores are computed correlating the results from propagating
form the query network to the target network and correlating target nodes
from within the target network.

For more specific information about the methods used for ProphNet propagation,
please read our 
`paper <http://bmcbioinformatics.biomedcentral.com/articles/10.1186/1471-2105-15-S1-S5>`_:

Martínez, Víctor, Carlos Cano, and Armando Blanco. 
"ProphNet: A generic prioritization method through propagation of information." 
BMC bioinformatics 15.1 (2014): 1.


