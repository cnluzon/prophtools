import matplotlib
# Force matplotlib to not use any Xwindows backend.
matplotlib.use('Agg')

